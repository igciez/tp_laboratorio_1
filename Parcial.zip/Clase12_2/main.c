#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Cliente.h"
#include "utn.h"
#include "Publicacion.h"
#include "Informe.h"

#define QTY 100
#define LEN_PUBL  1000

int main()
{
    Cliente clientes[QTY];
    Publicacion publicaciones[LEN_PUBL];

    int menu;
    int auxiliarId;

/*
    cliente_init(clientes,QTY);
    publicacion_init(publicaciones,LEN_PUBL);

    cliente_altaForzada(clientes,QTY,"Juan","Perez","321645");
    cliente_altaForzada(clientes,QTY,"Cristian","aldo","2333456");
    cliente_altaForzada(clientes,QTY,"Pedro","Mirno","32178945");
    cliente_altaForzada(clientes,QTY,"Laura","EStel","3224565");


    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "alfombra", 4, 0,1);
    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "carpeta", 5, 0, 0);
    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "alfombra", 4, 0,1);
    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "pizarron", 6, 0, 1);
    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "escritorio", 7, 2, 1);
    publicacion_altaForzada(publicaciones,LEN_PUBL, clientes, QTY, "escritorio", 7, 2, 0);
*/

    do
    {
        getValidInt("\n\n1.Alta Cliente\n2.Modificar datos del cliente.\n3.Baja del Cliente.\n4.Publicar\n5.Pausar publicacion.\n6.Reanudar Publicacion.\n7.Imprimir Clientes.\n8.Imprimir Publicaciones.\n9.Informar Clientes.\n10.Informar Publicaciones.\n11.Salir\n","\nDato ingresado no valido\n",&menu,1,11,2);
        switch(menu)
        {
            case 1:
                if(!cliente_alta(clientes,QTY))
                {
                  cliente_mostrar(clientes,QTY);
                }
                else
                {
                    printf("\nHa ocurrido un error durante la carga del alta, por favor, vuelva a intentar.\n");
                }
                break;
            case 2:
                cliente_mostrar(clientes,QTY);
                getValidInt(" \nIngrese ID del cliente:","\nNumero no valido\n",&auxiliarId,0,100,2);
                cliente_modificacion(clientes,QTY,auxiliarId);
                break;
            case 3:
                cliente_mostrar(clientes,QTY);
                getValidInt("\nIngrese ID del cliente: ","\nNumero no valido\n",&auxiliarId,0,100,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\nPara confirmar la eliminacion reingrese ID del cliente: ","\nNumero no valido\n",&auxiliarId,0,100,2);
                cliente_baja(clientes,QTY,auxiliarId);
                publicacion_baja(publicaciones, LEN_PUBL, auxiliarId);
                break;
            case 4:
                cliente_mostrar(clientes,QTY);
                publicacion_alta(publicaciones,LEN_PUBL, clientes, QTY);
                break;
            case 5:
                publicacion_soloMostrar(publicaciones,LEN_PUBL);
                getValidInt("\n\nIngrese ID de la Publicacion: ","\nNumero no valido\n",&auxiliarId,0,1000,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\n\nSi quiere pausar la publicacion, reingrese el ID publicacion: ","\nNumero no valido\n",&auxiliarId,0,1000,2);
                publicacion_modificacionActiva(publicaciones,LEN_PUBL, auxiliarId);
                break;
            case 6:
                publicacion_soloMostrar(publicaciones,LEN_PUBL);
                getValidInt("\n\nIngrese ID de la Publicacion: ","\nNumero no valido\n",&auxiliarId,0,1000,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\nSi quiere activar la publicacion, reingrese el ID publicacion: ","\nNumero no valido\n",&auxiliarId,0,1000,2);
                publicacion_modificacionPausada(publicaciones,LEN_PUBL, auxiliarId);
                break;
            case 7:
                cliente_soloMostrarActivos(publicaciones,LEN_PUBL, clientes, QTY);
                break;
            case 8:
                publicacion_soloMostrarActivos(publicaciones,LEN_PUBL, clientes, QTY);
                break;
            case 9:
                informe_cliente(clientes, QTY, publicaciones,LEN_PUBL);
                break;
            case 10:
                publicacion_soloMostrar(publicaciones,LEN_PUBL);
                getValidInt("\n\nIngrese el numero del rubro: ","\nNumero no valido\n",&auxiliarId,0,1000,2);
                informe_publicacion(publicaciones, LEN_PUBL, auxiliarId);
                break;
        }

    }while(menu != 11);

    return 0;
}
