#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Publicacion.h"
#include "utn.h"
#include "Publicacion.h"



/** \brief informa los clientes en base a la cantidad de aviso totales, avisos activos y avisos pausados.
 *
 * \param Cliente* arrayC,estructura a buscar en base al id de cliente.
 * \param int limiteC, cantidad de estructuras de clientes.
 * \param Publicacion* array, estructura a buscar estado activo.
 * \param int limite, cantidad de estructuras de publicacion.
 * \return int, valor entero.
 *
 */

int informe_cliente(Cliente* arrayC, int limiteC, Publicacion* arrayP, int limiteP)
{
    int i,j;
    int acumuladorActivo=0;
    int acumuladorPausado=0;
    int acumuladorTotal=0;
    int maximoA;
    int maximoP;
    int maximoT;
    int flag=1;

    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        //--------------------------------//busqueda del mas activo, mas pausado y del total de avisos publicados.
        for(i=0;i <limiteC; i ++)
        {

            acumuladorTotal=0;
            acumuladorActivo=0;
            acumuladorPausado=0;

            for(j = 0;j < limiteP;j ++)
            {
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 1)
                {
                    acumuladorActivo++;
                    acumuladorTotal++;
                }
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 0)
                {
                   acumuladorPausado++;
                   acumuladorTotal++;
                }
            }
            if(flag && acumuladorTotal >=1)
            {
                flag=0;

                maximoA=acumuladorActivo;
                maximoP=acumuladorPausado;
                maximoT=acumuladorTotal;
            }
            if(acumuladorActivo >= maximoA && !flag)
            {
                maximoA=acumuladorActivo;
            }
            if(acumuladorPausado >= maximoP && !flag)
            {
                maximoP=acumuladorPausado;
            }
            if(acumuladorTotal >= maximoT && !flag)
            {
                maximoT=acumuladorTotal;
            }
        }
        //--------------------------// Imprimir los maximos y los totales.
        for(i=0;i <limiteC; i ++)
        {

            acumuladorTotal=0;
            acumuladorActivo=0;
            acumuladorPausado=0;

            for(j = 0;j < limiteP;j ++)
            {
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 1)
                {
                    acumuladorActivo++;
                    acumuladorTotal++;
                }
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 0)
                {
                   acumuladorPausado++;
                   acumuladorTotal++;
                }
            }
            if(acumuladorActivo >= maximoA)
            {
               printf("\nId del cliente con mas aviso activos: ID %d.\nCon la cantidad de avisos activos: %d.\n",arrayC[i].idCliente,maximoA);
            }
            if(acumuladorPausado >= maximoP)
            {
                 printf("\nId del cliente con mas avisos pausados: ID %d.\nCon la cantidad de avisos pausados: %d.\n",arrayC[i].idCliente,maximoP);
            }
            if(acumuladorTotal >= maximoT && !flag)
            {
               printf("\nId del cliente con mas avisos (activos + pausados): ID %d.\nCon la cantidad total de avisos: %d.\n",arrayC[i].idCliente,maximoT);
            }
        }
    }
    return 0;
}


/** \brief informa, la cantidad de publicaciones activas de un rubro determinado por el usuario. Ademas, el rubro con mas y con menos, publicaciones activas.
 *
 * \param Publicacion* array, estructura a informar sobre rubros con publicaciones activas.
 * \param int limite, cantidad de estructuras a buscar para informar rubros con publicaciones activas.
 * \param int rubro, valor ingresado por usuario, para comparar con el campo rubro de la estructura publicacion.
 * \return int, valor entero.
 *
 */
int informe_publicacion(Publicacion* array, int limite, int rubro)
{
    int i, j;
    int acumuladorActivas=0;
    int flag=1;
    int maximoActivas;


    for(i = 0;i < limite; i++) // busca cantidad de publicaciones activas para un rubro
    {
        if(!array[i].isEmpty && array[i].rubro == rubro && array[i].estadoActivo == 1)
        {
            acumuladorActivas++;
        }
    }
    if(acumuladorActivas >= 1)
    {
        printf("\nLa cantidad de publicaciones activas para el rubro %d es: %d.\n",rubro, acumuladorActivas);
    }
    else
    {
        printf("\nNo se encontro activo el rubro buscado.\n");
    }
 //------------------------------//ordenar el array publicaciones de mayor a menor rubro, para encontrar el maximo

  publicacion_ordenar(array,limite,1);

//----------------------------------------//buscar el minimo y maximo de publicaciones activas

    for(i = 0;i < limite; i++)
    {
        acumuladorActivas=0;

        for(j = 0;j < limite; j++)
        {
            if(!array[i].isEmpty && !array[j].isEmpty && array[i].rubro == array[j].rubro && array[i].estadoActivo == 1 && array[j].estadoActivo ==1)
            {
                acumuladorActivas++;
            }
        }
        if(flag && acumuladorActivas >= 1)
        {
            flag=0;
            maximoActivas=acumuladorActivas;
        }
        else if(acumuladorActivas >= maximoActivas && !flag)
        {
            printf("\nRubro %d con mas publicaciones activas.\n",array[i].rubro);
        }
        else if(acumuladorActivas == 1 && !flag)
        {
           printf("\nRubro %d con menos publicaciones activas.\n",array[i].rubro);
        }
    }
    return 0;
}
