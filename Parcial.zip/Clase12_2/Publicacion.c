#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Publicacion.h"
#include "utn.h"



//Funciones privadas
static int proximoId(void);
static int buscarPorId(Publicacion* array,int limite, int id);
static int buscarLugarLibre(Publicacion* array,int limite);
//__________________



/** \brief inicializa la estructura publicacion.
 * \param array Pantalla*, estructura a inicializar.
 * \param limite int, cantidad de estructuras a inicializar.
 * \return int, valor entero.
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}

/** \brief muestra los campos dentro de la estrucura publicacion, en base al id.
 *
 * \param Publicacion* array, estructura donde se muestran los campos.
 * \param int limite, cantidad de esctructuras a buscar para mostrar.
 * \param id, numero de identificacion de la publicacion para ser mostrado.
 * \return int, valor entero.
 *
 */

int publicacion_mostrar(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion == id)
            {
                printf("\nID del Cliente: %d.\nNumero del rubro: %d.\nTexto del aviso: %s.\nID de la publicacion: %d.\n",array[i].idCliente, array[i].rubro,array[i].textoAviso,array[i].idPublicacion);
                retorno=1;
            }

        }
    }
    return retorno;
}

/** \brief muestra todos los campos de la estructura publicacion, sin tener en cuenta un valor base.
 *
 * \param Publicacion* array, estructura donde se mostraran sus campos.
 * \param int limite, cantidad de estructuras a buscar para mostrar.
 * \return int, valor entero.
 *
 */
int publicacion_soloMostrar(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("\nID de la publicacion: %d.\nNumero del rubro: %d.\nTexto del aviso: %s.\nEstado de la publicacion (activo = 1): %d\n",array[i].idPublicacion, array[i].rubro,array[i].textoAviso, array[i].estadoActivo);
        }
    }
    return retorno;
}


/** \brief modifica el campo estado 0, de la estructura publicacion, al campo estado 1.
 *
 * \param Publicacion* array, estructura donde se modifican el campo estado.
 * \param int limite, cantidad de esctructuras a buscar para modificar el campo estado.
 * \param id, numero de identificacion de la publicacion para ser modificado el campo estado.
 * \return int, valor entero.
 *
 */

int publicacion_modificacionPausada(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    int indiceAModificar;

    if(limite > 0 && array != NULL)
    {
            retorno = -2;
            for(i=0;i<limite;i++)
            {
                if(!array[i].isEmpty && array[i].idPublicacion==id)
                {
                    indiceAModificar= i;
                    break;
                }
            }
    }
    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
            array[indiceAModificar].estadoActivo=1;
    }
    else
    {
            retorno = -3;
    }
    return retorno;
}

/** \brief muestra las estructuras de publicacion con el campo estado 1 de publicacion, en relacion con el id de cliente, junto a la estructura cliente.
 *
 * \param Publicacion* array, estructura donde se encuentra campo estado 1, y el id de cliente a relacionar.
 * \param int limite, cantida de estructuras de publicacion a buscar el campo estado 1 y el id de cliente.
 * \param Cliente* arrayC, estructura con campo id cliente, con la cual se relaciona el campo id cliente, de estructura publicacion.
 * \param int limiteC, cantida de estructuras de cliente a buscar el campo id de cliente.
 * \return int, valor entero.
 *
 */

int publicacion_soloMostrarActivos(Publicacion* array,int limite, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int j;


    if(limite > 0 && limiteC > 0 && array != NULL && arrayC != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteC;i++)
        {
            for(j=0; j < limite; j++)
            {
                if(!(arrayC[i].isEmpty) && !(array[j].isEmpty) && array[j].idCliente == arrayC[i].idCliente && array[j].estadoActivo == 1)
                {
                    printf("\nRubro : %d.\nTexto: %s.\nCuit: %s.\nId de la publicacion: %d.\nEstado de la publicacion (activo = 1)= %d.\n", array[j].rubro, array[j].textoAviso, arrayC[i].cuit, array[j].idPublicacion,array[j].estadoActivo);
                }
            }
        }
    }
    return retorno;
}

/** \brief modifica el campo estado 1, de la estructura publicacion, al campo estado 0.
 *
 * \param Publicacion* array, estructura donde se modifican el campo estado.
 * \param int limite, cantidad de esctructuras a buscar para modificar el campo estado.
 * \param id, numero de identificacion de la publicacion para ser modificado el campo estado.
 * \return int, valor entero.
 *
 */
int publicacion_modificacionActiva(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    int indiceAModificar;

    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idPublicacion==id)
            {
                indiceAModificar= i;
                break;
            }
        }
    }
    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
            array[indiceAModificar].estadoActivo=0;
    }
    else
    {
            retorno = -3;
    }

    return retorno;
}

/** \brief carga los campos de la estructura publicacion, teniendo la relacion id cliente, con la estructura cliente.
 *
 * \param Publicacion* array, estructura donde se cargan sus campos y el id de cliente a relacionar.
 * \param int limiteP, cantida de estructuras de publicacion a buscar para cargar los campos.
 * \param Cliente* arrayC, estructura con campo id cliente, con la cual se relaciona el campo id cliente, de estructura publicacion.
 * \param int limiteC, cantida de estructuras de cliente a buscar el campo id de cliente.
 * \return int, valor entero.
 *
 */
int publicacion_alta(Publicacion* arrayP,int limiteP, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int p;
    int idCliente;
    int rubro;
    char texto[64];


    if(limiteP > 0 && arrayP != NULL)
    {
        i = buscarLugarLibre(arrayP,limiteP);
        if(i >= 0)
        {
            getValidInt("\nIngrese el ID del cliente: ","\nNumero no valido\n",&idCliente,0,999999,2);
            p= cliente_buscarPorId(arrayC,limiteC, idCliente);

            if( p != -2)
            {
                getValidInt("\nIngrese un numero para el rubro:","\nNumero no valido\n",&rubro,0,200,2);
                getValidString("\nIngrese el texto del aviso: ","\nTexto ingresado no valido","\nFuera de los limites",texto,64,2 );
                arrayP[i].rubro = rubro;
                strcpy(arrayP[i].textoAviso,texto);
                arrayP[i].idCliente = idCliente; // relacion
                arrayP[i].isEmpty=0;
                arrayP[i].idPublicacion = proximoId();
                arrayP[i].estadoActivo=1;
            }
            else
            {
                printf("\nID ingresado no se corresponde con un cliente registrado.");
            }
        }
        else
        {
            retorno = -2;
        }
    }
    return retorno;
}
/** \brief carga los campos de la estructura publicacion, sin pasar por el menu, sino directamente al ser colocados en la funcion.
 *
* \param Publicacion* arrayP, estructura donde se cargan sus campos y el id de cliente a relacionar.
 * \param int limiteP, cantida de estructuras de publicacion a buscar para cargar los campos.
 * \param Cliente* arrayC, estructura con campo id cliente, con la cual se relaciona el campo id cliente, de estructura publicacion.
 * \param int limiteC, cantida de estructuras de cliente a buscar el campo id de cliente.
 * \param char* texto, texto a cargar en el campo de publicacion texto aviso.
 * \param int rubro, numero a cargar en el campo rubro de publicacion.
 * \param int idCliente, id con el cual verificar su existencia en estructura cliente.
 * \param int estado, numero a cargar en el campo estado de publicacion.
 * \return int, valor entero.
 *
 */

int publicacion_altaForzada(Publicacion* arrayP,int limiteP, Cliente* arrayC, int limiteC, char* texto, int rubro, int idCliente, int estado)
{
    int retorno = -1;
    int i;
    int p;


    if(limiteP > 0 && arrayP != NULL)
    {
        i = buscarLugarLibre(arrayP,limiteP);
        if(i >= 0)
        {

            p= cliente_buscarPorId(arrayC,limiteC,idCliente);

            if( p != -2)
            {
                arrayP[i].rubro = rubro;
                strcpy(arrayP[i].textoAviso,texto);

                arrayP[i].idCliente = idCliente; // relacion
                arrayP[i].isEmpty=0;
                arrayP[i].idPublicacion = proximoId();
                arrayP[i].estadoActivo=estado;
            }
            else
            {
                printf("\nID ingresado no se corresponde con un cliente registrado.");
            }
        }
        else
        {
            retorno = -2;
        }
    }
    return retorno;
}

/** \brief cambia el campo isEmpty de 0 a 1, de la estructura publicacion, en base a un id ingresado.
 *
 * \param Publicacion* array, estructura donde cambiar el campo isEmpty.
 * \param int limite, cantida de estructuras publicacion a buscar en base al id y isEmpty 0.
 * \param int id, numero ingreado para ser buscado en el campo id publicacion, de la estructura publicacion.
 * \return int, valor entero.
 *
 */
int publicacion_baja(Publicacion* array,int limite, int id)
{
    int indiceAEliminar;
    int retorno=-1;
    indiceAEliminar = buscarPorId(array,limite,id);
    if(indiceAEliminar>=0)
    {
        array[indiceAEliminar].isEmpty=1;
        retorno=0;
    }
    return retorno;
}


/** \brief orden el campo rubro de la estructura publicacion.
 * \param Publicacion* array, estructura a ordenar un determinado campo.
 * \param limite, cantidad de estructuras a buscar.
 * \param orden 1, mayor a menor. orden 0, de menor a mayor.
 * \return
 *
 */
int publicacion_ordenar(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if(((array[i].rubro > array[i+1].rubro) && orden) || ((array[i].rubro < array[i+1].rubro) && !orden))
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}


/** \brief busca un lugar donde isEmpty sea 1, dentro de la esctructura publicacion.
 *
 * \param Publicacion* array, estructura a buscar lugar libre.
 * \param limite, cantidad de estructuras para buscar.
 * \return int, un valor entero.
 *
 */
static int buscarLugarLibre(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


/** \brief completa el campo id, de la estructura con un valor entero consecutivo.
 *
 * \param void, no se le ingresa valor.
 *
 * \return int, valor entero.
 *
 */
static int proximoId(void)
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}

/** \brief busca por id, dentro de la estructura publicacion.
 *
 * \param Publicacion* array, estructura a buscar.
 * \param limite, cantidad de estructuras a buscar.
 * \param id, valor por el cual buscar dentro de la estructura.
 * \return int, valor entero.
 *
 */
//int pantalla_buscarPorId(Pantalla* array,int limite, int id)
static int buscarPorId(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}




