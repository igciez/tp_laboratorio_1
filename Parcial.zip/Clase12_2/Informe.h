#ifndef INFORME_H_INCLUDED
#define INFORME_H_INCLUDED
#include "Cliente.h"
#include "Publicacion.h"


int informe_cliente(Cliente* arrayC, int limiteC, Publicacion* arrayP, int limiteP);
int informe_publicacion(Publicacion* array, int limite, int rubro);


#endif // INFORME_H_INCLUDED
