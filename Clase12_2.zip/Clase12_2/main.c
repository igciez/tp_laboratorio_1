#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Cliente.h"
#include "utn.h"
#include "Publicacion.h"


#define QTY 100
#define LEN_PUBL    1000

int main()
{
    Cliente clientes[QTY];
    Publicacion publicaciones[LEN_PUBL];

    int menu;
    int auxiliarId;
    //float auxAcumuladorPrecio;
    //int auxAcumuladorPantalla;
    //float promedio;

    cliente_init(clientes,QTY);
    publicacion_init(publicaciones,LEN_PUBL);

  /*  cliente_altaForzada(clientes,QTY,"Juan","Perez","321645");
    cliente_altaForzada(clientes,QTY,"Cristian","aldo","2333456");
    cliente_altaForzada(clientes,QTY,"Pedro","Mirno","32178945");
    cliente_altaForzada(clientes,QTY,"Laura","EStel","3224565");
*/
/*
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,0,"video.avi","20911911915",100);
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,0,"video1.avi","20911911915",400);
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,0,"video2.avi","30911911915",300);
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,2,"video3.avi","30911911915",400);
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,2,"video4.avi","40911911915",500);
    cont_altaForzada(contrataciones,LEN_CONT,array,QTY,2,"video5.avi","40911911915",600);

    informar_ConsultaFacturacion(contrataciones,LEN_CONT,array,QTY,"20911911915");
    informar_ListarContrataciones(contrataciones,LEN_CONT,array,QTY);
    informar_ListarCantidadContratacionesImporte(contrataciones,LEN_CONT,array,QTY);
    */

    do
    {
        getValidInt("\n\n1.Alta Cliente\n2.Modificar datos del cliente.\n3.Baja del Cliente.\n4.Publicar\n5.Pausar publicacion.\n6.Reanudar Publicacion.\n7.Imprimir Clientes.\n8.Imprimir Publicaciones.\n9.Listar pantallas que superen el promedio de dias de Contratacion.\n10.Pantallas que superen el promedio de los precios.\n11.Pantallas con mas de una publicacion.\n12.Listar Pantallas indicando facturacion.\n13.Pantallas con mas facturacion.\n14.Pantalla con mayor contratacion.\n15.Contratacion mas costosa.\n20.Salir\n","\nNo valida\n",&menu,1,20,1);
        switch(menu)
        {
            case 1:
                cliente_alta(clientes,QTY);
                break;
            case 2:
                cliente_mostrar(clientes,QTY);
                getValidInt(" \nIngrese ID del cliente:","\nNumero no valido\n",&auxiliarId,0,40,2);
                cliente_modificacion(clientes,QTY,auxiliarId);
                break;
            case 3:
                cliente_mostrar(clientes,QTY);
                getValidInt("\nIngrese ID del cliente: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\nPara confirmar la eliminacion reingrese ID del cliente: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                cliente_baja(clientes,QTY,auxiliarId);
                break;
            case 4:
                cliente_mostrar(clientes,QTY);
                publicacion_alta( publicaciones,LEN_PUBL,clientes,QTY);
                break;
            case 5:
                publicacion_soloMostrar(publicaciones,LEN_PUBL);
                getValidInt("\nIngrese ID de la Publicacion: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\nSi quiere pausar reingrese el ID publicacion: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                publicacion_modificacionActiva(publicaciones,LEN_PUBL, auxiliarId);
                break;
            case 6:
                publicacion_soloMostrar(publicaciones,LEN_PUBL);
                getValidInt("\nIngrese ID de la Publicacion: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                publicacion_mostrar(publicaciones, LEN_PUBL, auxiliarId);
                getValidInt("\nSi quiere pausar reingrese el ID publicacion: ","\nNumero no valido\n",&auxiliarId,0,40,2);
                publicacion_modificacionPasiva(publicaciones,LEN_PUBL, auxiliarId);
                break;
            case 7:
                publicacion_soloMostrarActivos(publicaciones,LEN_PUBL, clientes, QTY);
                break;
            case 8:
                //pantalla_cantidad(array, QTY, &auxAcumuladorPrecio, &auxAcumuladorPantalla);
                //auxAcumuladorPantalla=pantalla_acumuladorPantalla( array,QTY);
                //auxAcumuladorPrecio=pantalla_acumuladorPrecio( array, QTY);
                //promedio=(auxAcumuladorPrecio / auxAcumuladorPantalla);
                //pantalla_mostrarSuperaPromedio( array, QTY , &promedio);
                break;
            case 9:
                //auxAcumuladorPrecio=cont_acumuladorDias(contrataciones, LEN_CONT);
                //auxAcumuladorPantalla=cont_acumuladorContrataciones(contrataciones,LEN_CONT);
                //promedio=(auxAcumuladorPrecio / auxAcumuladorPantalla);
                //cont_ordenarIdPantalla(contrataciones,LEN_CONT);
                //cont_mostrarSuperaPromedio(contrataciones,LEN_CONT, &promedio);// !!agregar dentro de la funcion, el ordenar.!!
                break;
            case 10:
                //auxAcumuladorPantalla=pantalla_acumuladorPantalla( array,QTY);
                //auxAcumuladorPrecio=pantalla_acumuladorPrecio( array, QTY);
                //promedio=(auxAcumuladorPrecio / auxAcumuladorPantalla);
               // pantalla_mostrarNoSuperaPromedio( array, QTY , &promedio);
                break;
            case 11:
                //pantalla_PantallaMasDeUnaPublicacion(contrataciones, LEN_CONT,array, QTY);
                break;
            case 12:
                //pantalla_facturacion(contrataciones, LEN_CONT, array, QTY);
                break;
            case 13:
                //pantalla_Mayorfacturacion(contrataciones,LEN_CONT,array,QTY);
                break;
            case 14:
                //pantalla_MayorContratacion(contrataciones,LEN_CONT,array,QTY);
                break;
            case 15:
                //pantalla_ContratacionMasCostosa(contrataciones,LEN_CONT,array,QTY);//Corregir!(porque es igual a la 13)
                break;

        }

    }while(menu != 20);

    return 0;
}
