#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED

typedef struct
{
    char cuit[50];
    int idCliente;
    int rubro;
    char textoAviso[64];
    int estadoActivo;
    int estadoPausado;
    //------------
    int idPublicacion;
    int isEmpty;
}Publicacion;

#include "Cliente.h"


int publicacion_init(Publicacion* array,int limite);
int publicacion_mostrar(Publicacion* array,int limite, int id);
int publicacion_soloMostrar(Publicacion* array,int limite);

int publicacion_mostrarDebug(Publicacion* array,int limite);

//int publicacion_alta(Publicacion* arrayC,int limite,
              //Pantalla* pantallas, int lenPantallas);
int publicacion_alta(Publicacion* arrayP,int limiteP,
              Cliente* arrayC, int limitC);

int publicacion_baja(Publicacion* array,int limite, int id);
int publicacion_modificacionActiva(Publicacion* array,int limite, int id);
int publicacion_modificacionPasiva(Publicacion* array,int limite, int id);
//int publicacion_ordenar(Publicacion* array,int limite, int orden);
int publicacion_ordenarCuit(Publicacion* array,int limite, int orden);

int publicacion_ordenar(int* array,int limite);
int publicacion_ordenarIdPantalla(Publicacion* array,int limite);
float publicacion_acumuladorDias(Publicacion* array,int limite);
int publicacion_acumuladorPublicaciones(Publicacion* array,int limite);
int publicacion_mostrarSuperaPromedio(Publicacion* array,int limite, float* promedio);
int publicacion_PantallaMasDeUnaPublicacion(Publicacion* arrayC, int limiteC);
int publicacion_ImprimeDistintos(int* array,int limite);
//int publicacion_ImprimeDistintos(Publicacion* array,int limite);
//int buscarLugarLibre(Pantalla* array,int limite);
//int proximoId();
//int pantalla_buscarPorId(Pantalla* array,int limite, int id);


//int publicacion_altaForzada(Publicacion* arrayC,int limite,Pantalla* pantallas, int lenPantallas,int idPantalla,char* archivo,char* cuit,int dias);

#endif // PANTALLA_H_INCLUDED


