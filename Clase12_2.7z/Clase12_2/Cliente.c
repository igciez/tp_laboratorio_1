#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Cliente.h"
#include "utn.h"

#define DEFINE_DEL_ARCHIVO  "hola"

//Funciones privadas
static int proximoId(void);
static int buscarLugarLibre(Cliente* array,int limite);
//__________________



/** \brief
 * \param array Cliente*
 * \param limite int
 * \return int
 *
 */
int cliente_init(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}
/*
int cliente_mostrarDebug(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %s - %f - %d - %d\n",array[i].idCliente, array[i].nombre,array[i].direccion,array[i].precio,array[i].tipo, array[i].isEmpty);
        }
    }
    return retorno;
}
*/
int cliente_mostrar(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("\nNombre: %s. \nApellido:  %s.\nCuit: %s\nID cliente: %d.",array[i].nombre, array[i].apellido, array[i].cuit, array[i].idCliente);
        }
    }
    return retorno;
}
/*
int cliente_mostrarSuperaPromedio(Cliente* array,int limite, float* promedio)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
            {
                if(array[i].precio > *promedio)
                {
                   printf("\nPromedio: %.2f\n\n[RELEASE] - %d - %s - %.2f\n",*promedio,array[i].idCliente, array[i].nombre, array[i].precio);
                }
            }
        }
    }
    return retorno;
}

int cliente_mostrarNoSuperaPromedio(Cliente* array,int limite, float* promedio)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
            {
                if(array[i].precio < *promedio)
                {
                   printf("\nPromedio: %.2f\n\n[RELEASE] - %d - %s - %.2f\n",*promedio,array[i].idCliente, array[i].nombre, array[i].precio);
                }
            }
        }
    }
    return retorno;
}

int cliente_cantidad(Cliente* array,int limite, float *acumuladorPrecio, int *acumuladorCliente)
{
    int retorno = -1;
    int i;
    int cantidadCliente;


    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                {
                    cantidadCliente=+1;
                    *acumuladorCliente+= cantidadCliente;
                    *acumuladorPrecio += array[i].precio;
                }
        }
    }
    return retorno;
}


float cliente_acumuladorPrecio(Cliente* array,int limite)
{
    //int retorno = -1;
    int i;
    float acumuladorPrecio;


    if(limite > 0 && array != NULL)
    {
        //retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                {
                    acumuladorPrecio += array[i].precio;
                }
        }
    }
    return acumuladorPrecio;
}
*/
int cliente_acumuladorCliente(Cliente* array,int limite)
{
    //int retorno = -1;
    int i;
    int cantidadCliente;
    int acumuladorCliente=0;


    if(limite > 0 && array != NULL)
    {
        //retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                {
                    cantidadCliente=+1;
                    acumuladorCliente+= cantidadCliente;
                }
        }
    }
    return acumuladorCliente;
}

int cliente_alta(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    char nombre[50];
    char apellido[50];
    char cuit[50];;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre del Cliente: ","\nEso no es un nombre","El maximo es 40",nombre,40,2))
            {
                if(!getValidString("\nApellido del Cliente: ","\nApellido no valido","El maximo es 40",apellido,40,2))
                {
                    getString("\nIngrese el Cuit del cliente (sin esapacio):  ",cuit);

                            retorno = 0;
                            strcpy(array[i].nombre,nombre);
                            strcpy(array[i].apellido,apellido);
                            strcpy(array[i].cuit,cuit);
                            //------------------------------
                            //------------------------------
                            array[i].idCliente = proximoId();
                            array[i].isEmpty = 0;

                }
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int cliente_baja(Cliente* array,int limite, int id)
{
    int indiceAEliminar;
    int retorno=-1;
    indiceAEliminar = cliente_buscarPorId(array,limite,id);
    if(indiceAEliminar>=0)
    {
        array[indiceAEliminar].isEmpty=1;
        retorno=0;
    }
    return retorno;
}




int cliente_modificacion(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int indiceAModificar;
    char nombre[50];
    char apellido[50];
    char cuit[50];

    indiceAModificar = cliente_buscarPorId(array,limite,id);
    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
        if(!getValidString("\nIngrese el nombre: ","\nEso no es un nombre","El maximo es 40",nombre,40,2))
        {
            getValidString("\nIngrese el apellido: ","\nApellido no valido","El maximo es 40",apellido,40,2);
            getString("\nIngrese el Cuit del cliente (sin esapacio):  ",cuit);

            retorno = 0;
            strcpy(array[indiceAModificar].nombre,nombre);
            strcpy(array[indiceAModificar].apellido,apellido);
            strcpy(array[indiceAModificar].cuit,cuit);
            //------------------------------
            //TODO
        }
        else
        {
            retorno = -3;
        }
    }
    return retorno;
}

int cliente_ordenar(Cliente* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Cliente auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].nombre,array[i+1].nombre) > 0 && orden) || (strcmp(array[i].nombre,array[i+1].nombre) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

static int buscarLugarLibre(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}



static int proximoId(void)
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}


int cliente_buscarPorId(Cliente* array,int limite, int id)
//static int buscarPorId(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


int cliente_altaForzada(Cliente* array,int limite,char* nombre,char* apellido, char* cuit)
{
    int retorno = -1;
    int i;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].nombre,nombre);
            strcpy(array[i].apellido,apellido);
            strcpy(array[i].cuit,cuit);

            //------------------------------
            //------------------------------
            array[i].idCliente = proximoId();
            array[i].isEmpty = 0;
        }
        retorno = 0;
    }
    return retorno;
}


int cliente_soloMostrarActivos(Publicacion* array,int limite, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int j;
    int acumulador=0;

    if(limite > 0 && limiteC > 0 && array != NULL && arrayC != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteC;i++)
        {
            for(j=0; j < limite; j++)
            {
                if(!(arrayC[i].isEmpty) && !(array[j].isEmpty) && array[j].idCliente == arrayC[i].idCliente && array[j].estadoActivo == 1)
                {
                    acumulador++;
                }
            }
            if(acumulador > 1 )
            {
              printf("\nNombre : %s.\nApellido: %s.\nCuit: %s\nCantidad de activos: %d", arrayC[i].nombre, arrayC[i].apellido, array[i].cuit,acumulador);
            }
        }
    }
    return retorno;
}

/*
int cliente_ClienteMasDeUnaPublicacion(Contratacion* arrayC, int limiteC, Cliente* arrayP, int limiteP)
{
    int i,j;
    int acumulador=0;


    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        for(i=0;i <limiteP; i ++)
        {

            acumulador=0;

            for(j = 0;j < limiteC;j ++)
            {
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente)
                {
                    acumulador++;
                }
            }
            if(acumulador > 1 )
            {
               printf("\nCliente %d, con el nombre %s, posee la cantidad de contrataciones : %d", arrayP[i].idCliente, arrayP[i].nombre,acumulador);

            }
        }
    }
    return 0;
}
*/
/*
int cliente_facturacion(Contratacion* arrayC, int limiteC, Cliente* arrayP, int limiteP)
{
    int i,j;
    float acumulador=0;


    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        for(i=0;i <limiteP; i ++)
        {

            acumulador=0;

            for(j = 0;j < limiteC;j ++)
            {
                if(!(arrayC[j].isEmpty) && !(arrayP[i].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente)
                {
                    acumulador= acumulador + (arrayP[i].precio * arrayC[j].dias);
                }
            }
            if(!(arrayP[i].isEmpty) && acumulador > 0)
            {
               printf("\nCliente %d, con el nombre %s, Facturacion total : %.2f", arrayP[i].idCliente, arrayP[i].nombre,acumulador);

            }
        }
    }
    return 0;
}
*/

int cliente_MasActivo(Publicacion* arrayC, int limiteC, Cliente* arrayP, int limiteP)
{
    int i,j;
    float acumulador=0;
    float acumuladorDos=0;
    float maximo;
    float minimo;
    int retorno = 1;
    int flag=1;
    int auxId;


    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        for(i=0;i <limiteP; i ++)
        {

            acumulador=0;

            for(j = 0;j < limiteC;j ++)
            {
                if(!(arrayC[j].isEmpty) && !(arrayP[i].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente && arrayC[j].estadoActivo == 1)
                {
                    acumulador++;
                }
                if(!(arrayC[j].isEmpty) && !(arrayP[i].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente && arrayC[j].estadoActivo == 0)
                {
                   acumuladorDos++;
                }
            }
            if(!(arrayP[i].isEmpty) && acumulador > 0)
            {
                if(retorno)
                {
                    retorno=0;
                    flag=0;
                    maximo=acumulador;
                    minimo=acumuladorDos;
                }
                if(acumulador >= maximo && flag)
                {
                    maximo=acumulador;
                    auxId=arrayP[i].idCliente;
                    printf("\n", auxId,maximo);
                }
                if(acumuladorDos <= minimo && flag)
                {
                    minimo=acumuladorDos;
                    auxId=arrayP[i].idCliente;
                    printf("\n", auxId,maximo);
                }
                flag=1;
            }
        }
    }

    return 0;
}

/*
int cliente_MayorContratacion(Contratacion* arrayC, int limiteC, Cliente* arrayP, int limiteP)
{
    int i,j;
    float acumulador=0;
    float maximo;
    int retorno = 1;
    int flag =1;
    int auxId;


    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        for(i=0;i <limiteP; i ++)
        {

            acumulador=0;

            for(j = 0;j < limiteC;j ++)
            {
                if(!(arrayC[j].isEmpty) && !(arrayP[i].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente)
                {
                    acumulador= acumulador + 1;
                }
            }
            if(!(arrayP[i].isEmpty) && acumulador > 0)
            {
                if(retorno)
                {
                    retorno=0;
                    maximo=acumulador;
                    flag=0;
                }
                if(acumulador >= maximo && flag)
                {
                    maximo=acumulador;
                    auxId=arrayP[i].idCliente;
                    printf("\nCliente %d, Contratacion: %.2f", auxId,maximo);
                }
                flag=1;
            }
        }
    }

    return 0;
}
*/
/*
int cliente_ContratacionMasCostosa(Contratacion* arrayC, int limiteC, Cliente* arrayP, int limiteP)
{
    int i,j;
    float acumulador=0;
    float maximo;
    int retorno = 1;
    int flag = 1;
    int auxId;


    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        for(i=0;i <limiteP; i ++)
        {

            acumulador=0;

            for(j = 0;j < limiteC;j ++)
            {
                if(!(arrayC[j].isEmpty) && !(arrayP[i].isEmpty) && arrayP[i].idCliente == arrayC[j].idCliente)
                {
                    acumulador= acumulador + (arrayP[i].precio * arrayC[j].dias);
                }
            }
            if(!(arrayP[i].isEmpty) && acumulador > 0)
            {
                if(retorno)
                {
                    retorno=0;
                    flag=0;
                    maximo=acumulador;
                }
                if(acumulador >= maximo && flag)
                {
                    maximo=acumulador;
                    auxId=arrayP[i].idCliente;
                    printf("\nCliente %d, Contratacion: %.2f", auxId,maximo);
                }
                flag=1;
            }
        }
    }

    return 0;
}


*/
