#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Publicacion.h"
#include "utn.h"
//#include "Cliente.h"



//Funciones privadas
static int proximoId(void);
static int buscarPorId(Publicacion* array,int limite, int id);
static int buscarLugarLibre(Publicacion* array,int limite);
//__________________



/** \brief
 * \param array Pantalla*
 * \param limite int
 * \return int
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}

int publicacion_mostrarDebug(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            //printf("[DEBUG] - %d - %s - %s - %d - %d\n",array[i].id, array[i].cuit,array[i].archivo,array[i].dias, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_mostrar(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente == id)
                printf("ID del Cliente: %d.\nNumero del rubro: %d.\nTexto del aviso: %s.",array[i].idCliente, array[i].rubro,array[i].textoAviso);
        }
    }
    return retorno;
}
int publicacion_soloMostrar(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("ID de la publicacion: %d.\nNumero del rubro: %d.\nTexto del aviso: %s.",array[i].idPublicacion, array[i].rubro,array[i].textoAviso);
        }
    }
    return retorno;
}



int publicacion_modificacionPasiva(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    int indiceAModificar;

    if(limite > 0 && array != NULL)
    {
            retorno = -2;
            for(i=0;i<limite;i++)
            {
                if(!array[i].isEmpty && array[i].idPublicacion==id)
                {
                    indiceAModificar= i;
                    break;
                }
            }
    }
    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
            array[indiceAModificar].estadoActivo=0;
    }
    else
    {
            retorno = -3;
    }
    return retorno;
}
int publicacion_soloMostrarActivos(Publicacion* array,int limite, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int j;


    if(limite > 0 && limiteC > 0 && array != NULL && arrayC != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteC;i++)
        {
            for(j=0; j < limite; j++)
            {
                if(!(arrayC[i].isEmpty) && !(array[j].isEmpty) && array[j].idCliente == arrayC[i].idCliente && array[j].estadoActivo == 1)
                {
                    printf("\nRubro : %d.\nTexto: %s.\nCuit: %s.\nId de la publicacion: %d", array[j].rubro, array[j].textoAviso, arrayC[i].cuit, array[j].idPublicacion);
                }
            }
        }
    }
    return retorno;
}


int publicacion_modificacionActiva(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    int indiceAModificar;

    if(limite > 0 && array != NULL)
    {
            retorno = -2;
            for(i=0;i<limite;i++)
            {
                if(!array[i].isEmpty && array[i].idPublicacion==id)
                {
                    indiceAModificar= i;
                    break;
                }
            }
    }

    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
            array[indiceAModificar].estadoActivo=0;

            //------------------------------
            //TODO
    }
    else
    {
            retorno = -3;
    }

    return retorno;
}

int publicacion_alta(Publicacion* arrayP,int limiteP,
              Cliente* arrayC, int limitC)
{
    int retorno = -1;
    int i;
    int idCliente;
    int posPant;
    int rubro;
    char texto[64];


    if(limiteP > 0 && arrayP != NULL)
    {
        i = buscarLugarLibre(arrayP,limiteP);
        if(i >= 0)
        {
            // alta
            //TODO
            getValidInt("\nIngrese el ID del cliente: ","\nNumero no valido\n",&idCliente,0,999999,2);
            posPant = cliente_buscarPorId(arrayC,limitC,idCliente);
            if(posPant>=0)
            {
                // la pantalla existe, idPant es valido
                getValidInt("\nIngrese un numero para el rubro:","\nNumero no valido\n",&rubro,0,200,2);
                getValidString("\nIngrese el texto del aviso: ","\nTexto ingresado no valido","\nfuera de los limites",texto,64,2 );
                // hacer el resto
                arrayP[i].rubro = rubro;
                strcpy(arrayP[i].textoAviso,texto);
                //TODO
                arrayP[i].idCliente = idCliente; // relacion
                arrayP[i].isEmpty=0;
                arrayP[i].idPublicacion = proximoId();

            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int publicacion_baja(Publicacion* array,int limite, int id)
{
    int indiceAEliminar;
    int retorno=-1;
    indiceAEliminar = buscarPorId(array,limite,id);
    if(indiceAEliminar>=0)
    {
        array[indiceAEliminar].isEmpty=1;
        retorno=0;
    }
    return retorno;
}


static int buscarLugarLibre(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}



static int proximoId(void)
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}


//int pantalla_buscarPorId(Pantalla* array,int limite, int id)
static int buscarPorId(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}
/*
int publicacion_altaForzada(Publicacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas,
              int idPantalla,char* archivo,char* cuit,int dias)
{
    int retorno = -1;
    int i;
    int posPant;
    if(limite > 0 && arrayC != NULL)
    {
        i = buscarLugarLibre(arrayC,limite);
        if(i >= 0)
        {

            posPant = pantalla_buscarPorId(pantallas,lenPantallas,idPantalla);
            if(posPant>=0)
            {
                arrayC[i].dias = dias;
                strcpy(arrayC[i].cuit,cuit);
                strcpy(arrayC[i].archivo,archivo);
                //TODO
                arrayC[i].idPantalla = idPantalla; // relacion
                arrayC[i].isEmpty=0;
                arrayC[i].id = proximoId();
            }
        }
        retorno = 0;
    }
    return retorno;
}
float publicacion_acumuladorDias(Publicacion* array,int limite)
{
    //int retorno = -1;
    int i;
    float acumuladorDias=0;


    if(limite > 0 && array != NULL)
    {
        //retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                {
                    acumuladorDias+= array[i].dias;
                }
        }
    }
    return acumuladorDias;
}
int publicacion_acumuladorPublicaciones(Publicacion* array,int limite)
{
    //int retorno = -1;
    int i;
    int cantidadPublicaciones;
    int acumuladorPublicaciones=0;


    if(limite > 0 && array != NULL)
    {
        //retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                {
                    cantidadPublicaciones=+1;
                    acumuladorPublicaciones+= cantidadPublicaciones;
                }
        }
    }
    return acumuladorPublicaciones;
}

int publicacion_mostrarSuperaPromedio(Publicacion* array,int limite, float* promedio)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
            {
                if(array[i].dias > *promedio)
                {
                   printf("\nPromedio: %.2f\n\n[RELEASE] - %d - %d\n",*promedio,array[i].idPantalla, array[i].dias);
                }
            }
        }
    }
    return retorno;
}

int publicacion_ordenarCuit(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].cuit,array[i+1].cuit) > 0 && orden) || (strcmp(array[i].cuit,array[i+1].cuit) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}


int publicacion_ordenarIdPantalla(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if(array[i].idPantalla > array[i+1].idPantalla)
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int publicacion_ordenar(int* array,int limite)
{
    int retorno = -1;
    int i;
    int flagSwap;
    int auxiliarEstructura;

    //if(limite > 0 && array != NULL)
    //{
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                //if(!array[i] && !array[i+1])
                //{
                    if(array[i] > array[i+1])
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                //}
            }
        }while(flagSwap);
    //}
    return retorno;
}


int publicacion_ImprimeDistintos(int* array,int limite)
{
    int retorno = -1;
    int i;

    //if(limite > 0 && array != NULL)
    //{
        for(i=0;i<limite-1;i++)
            {
                //if(!array[i] && !array[i+1])
                //{
                    if(array[i] != array[i+1])
                    {
                        printf("\nPantalla %d, posee mas de una publicacion", array[i]);
                    }
                //}
            }
    //}
    return retorno;
}


*/



